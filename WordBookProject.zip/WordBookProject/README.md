
Tools used on the project
------------------------------------
* [Kotlin]
* [Android Architecture Components]
* [RxJava & RxAndroid]
* [Dagger 2]
* [Retrofit]
* [OkHttp]

