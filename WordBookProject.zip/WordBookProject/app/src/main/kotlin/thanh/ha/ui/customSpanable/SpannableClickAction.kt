package thanh.ha.ui.customSpanable

interface SpannableClickAction {

    fun onClick(string: String)
}
