package thanh.ha.data.error

internal interface NetworkListener {
    fun onInternetUnavailable()
}